
const all = {
    serviceUrl: "https://staging.healthandglow.com/api/catalog/product/v6/search/999?app=web&version=3.0.2&tag=loreal-paris&page=",
}

export default all;