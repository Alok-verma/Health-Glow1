import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import * as action from '../actions/action.js'
import { connect } from 'react-redux'

const mapStateToProps = state => ({
    GetDataState: state.GetDataReducer.GetDataState,
})

const mapDispatchToProps = dispatch => ({
    fetchGetData(pageNumber,pageRange,selectedOption,categoryName,shadeName) {
        dispatch(
            action.GetDataAction(pageNumber,pageRange,selectedOption,categoryName,shadeName)
        )
    },
})
class Filter extends Component {
    constructor(props) {
        super(props);
        this.state={
            categoryList: [{ label: "Lipstick", value: "lipstick",id:100 }],
            shadeList:[{ label: "Brown", value: "brown",id:101},{ label: "Maroon", value: "maroon",id:102},{ label: "Pink", value: "pink",id:103},{ label: "red", value: "Red",id:104}],
            categoryselectedField:[],
            shadeSelectedFileds:[],
            pageNumber:0,
            pageRange:12,
            selectedOption:null

        }
    }
    
    
    getCateogryStatus(id){
        try {
            let checked =false
            let selectedData= [...this.state.categoryList]
            selectedData.forEach((elements)=>{
                if(elements['id']===id){
                     checked =true
                    
                }
            })
            return checked
        } catch (error) {
            console.log(error)
            
        }
    }
    getShadeCheckedstatus(id){
        try {
            let checked =false
            let selectedData= [...this.state.shadeList]
            selectedData.forEach((elements)=>{
                if(elements['id']===id){
                     checked =true
                    
                }
            })
            return checked
        } catch (error) {
            console.log(error)
            
        }
    }

    getCategoryCheckedData(e,iter){
        try {
            var list=[]
            list= JSON.parse(JSON.stringify(this.state.categoryselectedField))
            if(list.includes(iter.value)){
                list.splice(list.indexOf(iter.value),1)
            }else{
                list.push(iter.value)
            }
            this.setState({
                categoryselectedField:list
            },()=>{
                localStorage.setItem("categoryselectedField", JSON.stringify(this.state.categoryselectedField));
            })
            
        } catch (error) {
            console.log(error)
            
        }
    }
    getShadeCheckedData(e,iter){
        try {
            var list=[]
            list= JSON.parse(JSON.stringify(this.state.shadeSelectedFileds))
            if(list.includes(iter.value)){
                list.splice(list.indexOf(iter.value),1)
            }else{
                list.push(iter.value)
            }
            this.setState({
                shadeSelectedFileds:list
            },()=>{
                localStorage.setItem("shadeSelectedFileds", JSON.stringify(this.state.shadeSelectedFileds));
            })
            
        } catch (error) {
            console.log(error)
            
        }
    }
    goToLandingPage(e){
        try {
            const{pageNumber,pageRange,selectedOption,categoryselectedField,shadeSelectedFileds}=this.state
            if(categoryselectedField !==null &&categoryselectedField.length>0){
                this.props.fetchGetData(pageNumber,pageRange,selectedOption,categoryselectedField)
            }else if(shadeSelectedFileds !==null && shadeSelectedFileds !==undefined && shadeSelectedFileds!==undefined &&shadeSelectedFileds.length>0){
                this.props.fetchGetData(pageNumber,pageRange,selectedOption,shadeSelectedFileds,shadeSelectedFileds)
            }
            this.props.history.push("/")
            
        } catch (error) {
            console.log(error)
            
        }
    }
    render() {
        return (
            <div class="col-sm-12 filter-page">
                <div className="d-flex">
                    <div className="p-2 flex-fill pointer"><Link to='/'>Back</Link></div>
                    <div className="p-2  flex-fill">Filter By</div>
                </div>
                <div className="d-flex">
                    <div className="p-2 flex-fill pointer">
                         <h5>Category</h5>
                    </div>

                    <div className="p-2 lipstic  flex-fill">
                    {(this.state.categoryList).length > 0 ?
                            <React.Fragment>
                                {this.state.categoryList.map((iter, index) => {
                                    return (
                                        <React.Fragment>
                                            <span><input type="checkbox" id={iter.id} Checked={this.getCateogryStatus(iter.id)} onChange={(e) => this.getCategoryCheckedData(e, iter)} value={iter.id} name={iter.value} /></span>&nbsp;
                                            <label for={iter.id}>{iter.label}</label> <br />
                                        </React.Fragment>
                                    )
                                })
                                }
                            </React.Fragment>
                            : ""
                        }
                        </div>
                </div>

                <div className="d-flex">
                    <div className="p-2 flex-fill pointer">
                          <h5>Shade</h5>
                    </div>
                    <div className="p-2  flex-fill">
                    {(this.state.shadeList).length > 0 ?
                            <React.Fragment>
                                {this.state.shadeList.map((iter, index) => {
                                    return (
                                        <React.Fragment>
                                            <span><input type="checkbox" id={iter.id} Checked={this.getShadeCheckedstatus(iter.id)} onChange={(e) => this.getShadeCheckedData(e, iter)} value={iter.id} name={iter.value} /></span>&nbsp;
                                            <label for={iter.id}>{iter.label}</label> <br />
                                        </React.Fragment>
                                    )
                                })
                                }
                            </React.Fragment>
                            : ""
                        }
                        </div>
                </div>
                
                <div className="col-sm-12">
                <button type="button" class="btn btn-primary" onClick={(e)=>{this.goToLandingPage(e)}}>Submit</button>

                </div>
            </div>
        )

    }
}
const filter = connect(mapStateToProps, mapDispatchToProps)(Filter)
export default filter;
