import React, { Component } from 'react';
import '../stylesheets/landingpage.css'
import * as action from '../actions/action.js'
import { connect } from 'react-redux'
import Pagination from "react-js-pagination";
import Select from 'react-select';
import { Link } from 'react-router-dom';
const sortByOptions = [
    { value: 'priority', label: 'Popularity',orderBy:"Aasc" },
    { value: 'discount', label: 'Discount',orderBy:"Adesc" },
    { value: 'Price', label: 'High-Low',orderBy:"Adesc" },
    { value: 'Price', label: 'Low-High',orderBy:"Adesc" },
  ];
const mapStateToProps = state => ({
    GetDataState: state.GetDataReducer.GetDataState,
})
const mapDispatchToProps = dispatch => ({
    fetchGetData(pageNumber,pageRange,selectedOption,categoryName,shadeName) {
        dispatch(
            action.GetDataAction(pageNumber,pageRange,selectedOption,categoryName,shadeName)
        )
    },
})


class LandingPageComp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            product:[],
            recordPerPage:12,
            totalRecords:"",
            pageRange:12,
            selectedOption:null,
            pageNumber:0,
            loaderIcon:false,
            categoryName:JSON.parse(localStorage.getItem("categoryselectedField")),
            shadeName:JSON.parse(localStorage.getItem("shadeSelectedFileds"))
        };
        this.handlePageChange=this.handlePageChange.bind(this)
    }

    
    handlePageChange = pageNumber => {
        this.setState({
            pageNumber:pageNumber,
            loaderIcon:true
        },()=>{
            const{pageNumber,pageRange,selectedOption,categoryName,shadeName}=this.state
            this.props.fetchGetData(pageNumber,pageRange,selectedOption,categoryName,shadeName);
            this.setState({loaderIcon:false})
        })
      }
    componentDidMount() {
       this.getData()
    }
    getData(){
        this.setState({loaderIcon:true})
        try {
            const{pageNumber,pageRange,selectedOption,categoryName,shadeName}=this.state
        if(categoryName !==null &&categoryName.length>0){
            this.props.fetchGetData(pageNumber,pageRange,selectedOption,categoryName)
            this.setState({loaderIcon:false})
        }else if(shadeName !==null && shadeName !==undefined && categoryName!==undefined &&categoryName.length>0){
            this.props.fetchGetData(pageNumber,pageRange,selectedOption,categoryName,shadeName)
            this.setState({loaderIcon:false})
        }else{
            this.props.fetchGetData(pageNumber,pageRange,selectedOption)
            this.setState({loaderIcon:false})
        }
        } catch (error) {
            console.log(error)
            
        }
    }
    handleChange = selectedOption => {
        this.setState({ 
            selectedOption,
            loaderIcon:true
         },()=>{
            this.props.fetchGetData(this.state.pageNumber,this.state.pageRange,this.state.selectedOption)
            this.setState({loaderIcon:false})
         });
      };

      clearLocalStorage(e){
          try {
            this.setState({loaderIcon:true})
            localStorage.removeItem("categoryselectedField");
            localStorage.removeItem("shadeSelectedFileds");
            const{pageNumber,pageRange,selectedOption}=this.state
            this.props.fetchGetData(pageNumber,pageRange,selectedOption)
            this.setState({loaderIcon:false})
          } catch (error) {
              console.log(error)
              
          }
      }

    render() {
        const { GetDataState } = this.props
        var data={}, product=[],totalRecords
        data =GetDataState.data
        if(data !==undefined){
            product=GetDataState.data.products
            totalRecords=GetDataState.data.totalCount
        }
       
        const { selectedOption } = this.state;
        return (
            <React.Fragment>
                <div className="col-sm-12 container justify-content-md-center mainpage">
                   <div className="row">
                        <div className="col-sm-9">
                        <h2  className="pointer" onClick={(e)=>{this.clearLocalStorage()}}>Health & Glow</h2>
                        </div>
                        <div className="col-sm-2">
                        <Select
                             placeholder={"SortBy"}
                              value={selectedOption}
                            onChange={this.handleChange}
                            options={sortByOptions}
                        />
                        </div>
                        <div className="col-sm-1 pointer">
                        <Link to='/filter'>Filter By</Link>

                        </div>

                    </div>
                    
                   
                    <div className="row">
                        {(product.length > 0 && product !== null) ?
                            <React.Fragment>
                                {product.map((iter, inde) => {
                                    return (
                                        <React.Fragment key={inde}>
                                            <div className="col-md-4 col-6 text-lg-center-text-md-center-text-sm-center " >
                                                <div className="col-sm-12" style={{ paddingBottom: "4rem" }}>
                                                    <img style={{ height: "15rem" }} src={iter.skuImageUrl} />

                                                    <div className="col-sm-9">
                                                        <p className="text-lg-center-text-md-center-text-sm-center">
                                                            {iter.parentCategoryName}
                                                        </p>

                                                    </div>

                                                </div>

                                            </div>
                                        </React.Fragment>
                                    )
                                })

                                }
                            </React.Fragment>
                            :
                            <React.Fragment>
                                <div className="offset-sm-3 d-flex justify-content-center">
                                <i className="fa fa-circle-o-notch fa-spin" style={{fontSize:"50px",color:"blue"}}></i>
                                </div>
                            </React.Fragment>

                        }
                    </div>
                    {(product).length > 0 && (product !== null) ?
                    <div className="pagination d-flex justify-content-center">
                    <Pagination 
                        itemClass="page-item"
                        linkClass="page-link" 
                        prevPageText='prev'
                        nextPageText='next'
                        firstPageText='first'
                        lastPageText='last'
                        activePage={this.state.pageNumber} 
                        itemsCountPerPage={10} 
                        totalItemsCount={totalRecords} 
                        pageRangeDisplayed={this.state.pageRange}
                        onChange={this.handlePageChange}
                        />
                    </div>:""}
                </div>
            </React.Fragment>
        )

    }
}
const LandingPage = connect(mapStateToProps, mapDispatchToProps)(LandingPageComp)
export default LandingPage
